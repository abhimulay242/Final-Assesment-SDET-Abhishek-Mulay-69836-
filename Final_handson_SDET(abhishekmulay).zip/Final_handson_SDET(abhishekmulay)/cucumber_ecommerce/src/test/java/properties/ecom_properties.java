package properties;

public class ecom_properties {
	public final static String Ecommmerce = System.getProperty("user.dir")+"\\Features\\ecom.feature";

}
