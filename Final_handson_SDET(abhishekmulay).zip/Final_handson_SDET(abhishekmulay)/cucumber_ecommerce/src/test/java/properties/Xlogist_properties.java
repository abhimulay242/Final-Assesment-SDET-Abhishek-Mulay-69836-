package properties;

public class Xlogist_properties {
	public final static String Ecommmerce = System.getProperty("user.dir")+"\\Features\\xlogist.feature";


}
