package TestCase;

import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import PO.po_question5;
import Utility.BrowserManager;
import Utility.ExtentReportManager;

public class testcase_question5 {
	WebDriver driver ; 
	JSONObject alldata;
	//ExtentTest extTest;
	//ExtentReports extReport;
	
	@BeforeClass
	public void beforeclass() {
		InputStream dataIS = null;
		ExtentReportManager.createReport("Xlogist Add Coupon");
		String Filename = "data_question5/AllData.json";
		dataIS = getClass().getClassLoader().getResourceAsStream(Filename);
		JSONTokener tokener = new JSONTokener(dataIS);
		alldata = new JSONObject(tokener);
		System.out.println("Data:" + alldata.toString());
	}
	
	@BeforeMethod
	@Parameters({"browser","url"})
	public void beforemoethod(String browser , String url) {
		driver = BrowserManager.openbrowser(browser);
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
	
	@Test(priority = 1)
	public void valid_xlogist() {
		ExtentReportManager.startTest("Valid test by entering valid coupon code to add coupon");
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String coupon_code = alldata.getJSONObject("coupon_code_valid").getString("code");
		String expected  = alldata.getJSONObject("coupon_code_valid").getString("expected");
		 po_question5 obj = PageFactory.initElements(driver, po_question5.class);
		obj.add_coupon_valid(username, password , coupon_code , expected);
	} 
	
	@Test(priority = 2)
	public void xlogist_invalid_special_char() {
		ExtentReportManager.startTest("Invalid test by entering special char coupon code to add coupon");
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String coupon_code = alldata.getJSONObject("coupon_code_invalid_special_char").getString("code");
		String expected  = alldata.getJSONObject("coupon_code_invalid_special_char").getString("expected");
		 po_question5 obj = PageFactory.initElements(driver, po_question5.class);
		obj.add_coupon_invalid_special_char(username, password , coupon_code , expected);
	} 

	@Test(priority = 3)
	public void xlogist_invalid_alpha_spaces() {
		ExtentReportManager.startTest("Invalid test by entering alpha spaces coupon code to add coupon");
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String coupon_code = alldata.getJSONObject("coupon_code_invalid_alpha_spaces").getString("code");
		String expected  = alldata.getJSONObject("coupon_code_invalid_alpha_spaces").getString("expected");
		 po_question5 obj = PageFactory.initElements(driver, po_question5.class);
		obj.add_coupon_invalid_alpha_spaces(username, password , coupon_code , expected);
	}
	
	@Test(priority = 4)
	public void xlogist_invalid_special_alpha_num() {
		ExtentReportManager.startTest("Invalid test by entering alpha numeric coupon code to add coupon");
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String coupon_code = alldata.getJSONObject("coupon_code_invalid_special_alpha_num").getString("code");
		String expected  = alldata.getJSONObject("coupon_code_invalid_special_alpha_num").getString("expected");
		 po_question5 obj = PageFactory.initElements(driver, po_question5.class);
		obj.add_coupon_invalid_alpha_num(username, password , coupon_code , expected);
	} 
	
	@Test(priority = 5)
	public void xlogist_invalid_min_len() {
		ExtentReportManager.startTest("Invalid test by entering only 2 alphabets in coupon code to add coupon");
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String coupon_code = alldata.getJSONObject("coupon_code_min_length").getString("code");
		String expected  = alldata.getJSONObject("coupon_code_min_length").getString("expected");
		 po_question5 obj = PageFactory.initElements(driver, po_question5.class);
		obj.add_coupon_invalid_min_length(username, password , coupon_code , expected);
	} 
	
	@Test(priority = 6)
	public void xlogist_invalid_max_len() {
		ExtentReportManager.startTest("Invalid test by entering 30 alphabets in coupon code to add coupon");
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String coupon_code = alldata.getJSONObject("coupon_code_max_length").getString("code");
		String expected  = alldata.getJSONObject("coupon_code_max_length").getString("expected");
		 po_question5 obj = PageFactory.initElements(driver, po_question5.class);
		obj.add_coupon_invalid_max_length(username, password , coupon_code , expected);
	} 
	
	@Test(priority = 7)
	public void xlogist_invalid_empty() {
		ExtentReportManager.startTest("Invalid test by entering empty values in coupon code to add coupon");
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String coupon_code = alldata.getJSONObject("coupon_code_empty").getString("code");
		String expected  = alldata.getJSONObject("coupon_code_empty").getString("expected");
		 po_question5 obj = PageFactory.initElements(driver, po_question5.class);
		obj.add_coupon_invalid_empty(username, password , coupon_code , expected);
	} 

	@AfterMethod
	public void close_browser() {
		driver.quit();
		ExtentReportManager.extReport.endTest(ExtentReportManager.extTest);

	}
	@AfterClass
	public void close_report() {
		ExtentReportManager.extReport.flush();
	}
}
