package TestCase;

import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import PO.po_question5;
import PO.po_question6;
import Utility.BrowserManager;
import Utility.ExtentReportManager;

public class testcase_question6 {
	WebDriver driver ; 
	JSONObject alldata;
	
	
	@BeforeClass
	public void beforeclass() {
		InputStream dataIS = null;
		String Filename = "data_question6/AllData.json";
		dataIS = getClass().getClassLoader().getResourceAsStream(Filename);
		JSONTokener tokener = new JSONTokener(dataIS);
		alldata = new JSONObject(tokener);
		System.out.println("Data:" + alldata.toString());
	}
	
	@BeforeMethod
	@Parameters({"browser","url"})
	public void beforemoethod(String browser , String url) {
		driver = BrowserManager.openbrowser(browser);
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
	
	@Test(priority = 1)
	public void valid_ecommerce() {
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String category = alldata.getJSONObject("valid").getString("code");
		 po_question6 obj = PageFactory.initElements(driver, po_question6.class);
		obj.add_category_valid(username, password , category);
	} 
	
	@Test(priority = 1)
	public void invalid_ecommerce1() {
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String category = alldata.getJSONObject("invalid_special_char").getString("code");
		 po_question6 obj = PageFactory.initElements(driver, po_question6.class);
		obj.add_category_invalid_special_char(username, password , category);
	}
	
	@Test(priority = 2)
	public void invalid_ecommerce2() {
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String category = alldata.getJSONObject("invalid_alpha_spaces").getString("code");
		 po_question6 obj = PageFactory.initElements(driver, po_question6.class);
		obj.add_category_alpha_spaces(username, password , category);
	} 
	
	@Test(priority = 3)
	public void invalid_ecommerce3() {
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String category = alldata.getJSONObject("invalid_special_alpha_num").getString("code");
		 po_question6 obj = PageFactory.initElements(driver, po_question6.class);
		obj.add_category_special_alpha_num(username, password , category);
	} 
	
	@Test(priority = 4)
	public void invalid_ecommerce4() {
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String category = alldata.getJSONObject("invalid_empty").getString("code");
		 po_question6 obj = PageFactory.initElements(driver, po_question6.class);
		obj.add_category_empty(username, password , category);
	} 

	
	@Test(priority = 5)
	public void invalid_image() {
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		 po_question6 obj = PageFactory.initElements(driver, po_question6.class);
		obj.invalid_image(username, password);
	} 
	
	@Test(priority = 5)
	public void valid_image() {
		String username = alldata.getJSONObject("Login_credentials").getString("Email");
		String password = alldata.getJSONObject("Login_credentials").getString("Password");
		String image = alldata.getJSONObject("select_image").getString("valid");

		 po_question6 obj = PageFactory.initElements(driver, po_question6.class);
		obj.valid_image(username, password , image);
	} 	
	
	@AfterMethod
	public void close_browser() {
		driver.quit();
	}
}
