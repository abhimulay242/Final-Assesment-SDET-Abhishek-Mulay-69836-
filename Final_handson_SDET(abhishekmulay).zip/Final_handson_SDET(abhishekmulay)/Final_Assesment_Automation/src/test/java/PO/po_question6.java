package PO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.relevantcodes.extentreports.LogStatus;

import Utility.ExtentReportManager;

public class po_question6 {
	WebDriver driver;
	public po_question6(WebDriver driver) {
		this.driver = driver;
			
		}
	
	@FindBy(how = How.XPATH , using = "//input[@id=\"useremail\"]")
	WebElement Login_username;
	
	@FindBy(how = How.XPATH , using = "//input[@id=\"password\"]")
	WebElement Login_password;
	
	@FindBy(how = How.XPATH , using = "//button[@class=\"btn btn-primary btn-flat m-b-30 m-t-30\"]")
	WebElement Login_button;
	
	@FindBy(how = How.XPATH , using = "(//li[@class=\"header-icon dib\"]//span)[1]")
	WebElement mainhun_btn;

	@FindBy(how = How.XPATH , using = "//i[@class=\"ti-power-off\"]")
	WebElement logout_btn;
	
	@FindBy(how = How.XPATH , using = "(//a[@class=\"sidebar-sub-toggle\"])[2]")
	WebElement Product_btn;

	@FindBy(how = How.XPATH , using = "//a[@href=\"https://products.pisystindia.com/Ecommerce/admin/category\"]")
	WebElement category_btn;
	
	@FindBy(how = How.XPATH , using = "//a[@href=\"https://products.pisystindia.com/Ecommerce/admin/category/edit/10\"]")
	WebElement action_edit_btn;
	
	@FindBy(how = How.XPATH , using = "//button[@type=\"submit\"]")
	WebElement update_btn;
	
	@FindBy(how = How.XPATH , using = "//input[@id=\"category_name\"]")
	WebElement textbox_btn;
	
	@FindBy(how = How.XPATH , using = "(//a[@class=\"ti-image\"])[1]")
	WebElement image_btn;
	
	@FindBy(how = How.XPATH , using = "//i[@class=\"fa fa-file-archive-o\"]")
	WebElement select_image;

	public void click_select_image(String path) {
		try {			Thread.sleep(4000);

			select_image.sendKeys(path);
			Thread.sleep(2000);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	public void click_login(String username , String password) {
		try {
			Thread.sleep(1000);
			Login_username.sendKeys(username);
			Thread.sleep(1000);
			Login_password.sendKeys(password);
			Thread.sleep(1000);
			Login_button.click();
			Thread.sleep(2000);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void click_logout() {
		try {
			Thread.sleep(1000);
			mainhun_btn.click();
			Thread.sleep(1000);
			logout_btn.click();
			Thread.sleep(1000);

		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void click_product() {
		try {
			Thread.sleep(2000);
			Product_btn.click();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void click_category() {
		try {
			Thread.sleep(2000);
			category_btn.click();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void click_action_Edit() {
		try {
			Thread.sleep(2000);
			action_edit_btn.click();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_update() {
		try {
			Thread.sleep(2000);
			update_btn.click();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void click_image() {
		try {
			Thread.sleep(2000);
			image_btn.click();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	

	public void enter_category_name(String cat_text) {
		try {
			Thread.sleep(2000);
			textbox_btn.sendKeys(cat_text);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void add_category_valid(String username , String password , String cat_text) {
		try {
			click_login(username, password);
			click_product();
			click_category();
			click_action_Edit();
			click_update();
			enter_category_name(cat_text);
			Thread.sleep(3000);
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void add_category_invalid_special_char(String username , String password , String cat_text) {
		try {
			click_login(username, password);
			click_product();
			click_category();
			click_action_Edit();
			click_update();
			enter_category_name(cat_text);
			Thread.sleep(3000);
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void add_category_alpha_spaces(String username , String password , String cat_text) {
		try {
			click_login(username, password);
			click_product();
			click_category();
			click_action_Edit();
			click_update();
			enter_category_name(cat_text);
			Thread.sleep(3000);
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void add_category_special_alpha_num(String username , String password , String cat_text) {
		try {
			click_login(username, password);
			click_product();
			click_category();
			click_action_Edit();
			click_update();
			enter_category_name(cat_text);
			Thread.sleep(3000);
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void add_category_empty(String username , String password , String cat_text) {
		try {
			click_login(username, password);
			click_product();
			click_category();
			click_action_Edit();
			click_update();
			enter_category_name(cat_text);
			Thread.sleep(3000);
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void invalid_image(String username , String password) {

		try {
			click_login(username, password);
			click_product();
			click_category();
			click_image();
			click_update();
			Thread.sleep(3000);
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
	
	}
	
	public void valid_image(String username , String password , String path) {

		try {
			click_login(username, password);
			click_product();
			click_category();
			click_image();
			click_select_image(path);
			click_update();
			Thread.sleep(3000);
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
	
	}
	
	
}
