package PO;
import java.io.InputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;

import Utility.ExtentReportManager;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class question10 {
	
 ResponseSpecification res;
     
     
     RequestSpecification req_spec;
     
     String str=" ";
     JSONObject obj;
     
	         @BeforeClass
	         public void setSpecification() {
	        	 InputStream dataIS = null;
	      		ExtentReportManager.createReport("Post Test");
	             res = RestAssured.expect();
	 
	             res.statusLine("HTTP/1.1 200 OK");
	             
	             res.contentType(ContentType.JSON);
	             
	             String Filename = "data_question10/apidata.json";
	             dataIS = getClass().getClassLoader().getResourceAsStream(Filename);
	             JSONTokener tokener = new JSONTokener(dataIS);
	     			obj = new JSONObject(tokener);	         }
	         
	         
	         @Test(priority=1)
	         public void UserLogin_valid() {
	             
	             HashMap<String,String> params = new HashMap<String, String>();
	             String Username = obj.getJSONObject("valid").getString("username");
	             String Password = obj.getJSONObject("valid").getString("password");

	             params.put("username", Username);
	             params.put("password", Password);
	             RestAssured.baseURI="https://arcadia.pisystindia.com/";
	             
	             
	             Response resp = given().when().contentType("application/json").body(params).post("api/login").then().contentType(ContentType.JSON).extract().response();
	             System.out.println("op is"+resp.asPrettyString());
	             LinkedHashMap<String,Object> payload= resp.body().jsonPath().get("payload");
	             
	             System.out.println(payload.toString());
	             
	             
	             
	         }
	         
	         @Test(priority=2)
	         public void UserLogin_invalid() {
	             
	             HashMap<String,String> params = new HashMap<String, String>();
	             String Username = obj.getJSONObject("invalid").getString("username");
	             String Password = obj.getJSONObject("invalid").getString("password");

	             params.put("username", Username);
	             params.put("password", Password);
	             RestAssured.baseURI="https://arcadia.pisystindia.com/";
	             
	             
	             Response resp = given().when().contentType("application/json").body(params).post("api/login").then().contentType(ContentType.JSON).extract().response();
	             System.out.println("op is"+resp.asPrettyString());
	             LinkedHashMap<String,Object> payload= resp.body().jsonPath().get("payload");
	             
	             System.out.println(payload.toString());
	             
	             
	             
	         }
	         
	         @AfterMethod
	         public void tearDown() {
	             ExtentReportManager.extReport.endTest(ExtentReportManager.extTest);
	         }
	         
	         @AfterClass
	         public void closeReport() {
	             ExtentReportManager.extReport.flush();
	         }
	         }
	         

