package PO;


import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Utility.ExtentReportManager;
import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class question9 {

	 ResponseSpecification res;
     
     
     RequestSpecification req_spec;
     
     String str=" ";
     JSONObject obj1;
     
     @BeforeClass
     public void setSpecification() {
 		ExtentReportManager.createReport("Get Test");
         res = RestAssured.expect();
         
         
         res.statusLine("HTTP/1.1 200 OK");
         
         res.contentType(ContentType.JSON);
     }
     
     @Test(description =  "getting general setting with valid url" , priority = 1)
     public void valid_general_Setting() {
 		ExtentReportManager.startTest("Valid test");
    	 RestAssured.baseURI="http://arcadia.pisystindia.com/";
         Response resp=given().header("Authorization",str).when().get("api/generalSetting").then().contentType(ContentType.JSON).extract().response();
         System.out.println("Get output is = "+resp.asPrettyString());
     }
     
     @Test(description =  "Using invalid url -> Tesctcase2" , priority = 2)
     public void invalid_general_setting() {
 		ExtentReportManager.startTest("Invalid test");
    	 RestAssured.baseURI="http://arcadia.pisystindiaasas.com/";
         Response resp=given().header("Authorization",str).when().get("api/generalSetting").then().contentType(ContentType.JSON).extract().response();
         System.out.println("Get output is = "+resp.asPrettyString());
     }
     


     
     @AfterMethod
     public void tearDown() {
 		ExtentReportManager.extReport.endTest(ExtentReportManager.extTest);
     }
     
     @AfterClass
     public void closeReport() {
         ExtentReportManager.extReport.flush();
     }
     }


