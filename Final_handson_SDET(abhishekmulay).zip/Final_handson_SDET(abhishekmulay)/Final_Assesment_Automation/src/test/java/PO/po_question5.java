package PO;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.relevantcodes.extentreports.LogStatus;

import Utility.ExtentReportManager;

public class po_question5 {
		WebDriver driver;
		public po_question5(WebDriver driver) {
			this.driver = driver;
		}



@FindBy(how = How.XPATH , using = "//input[@id=\"useremail\"]")
WebElement Login_username;

@FindBy(how = How.XPATH , using = "//input[@id=\"password\"]")
WebElement Login_password;

@FindBy(how = How.XPATH , using = "//button[@class=\"btn btn-primary btn-flat m-b-30 m-t-30\"]")
WebElement Login_button;

@FindBy(how = How.XPATH , using = "//a[@href=\"https://xlogist.pisystindia.com/mainhub/promocode\"]")
WebElement coupon_module_btn;

@FindBy(how = How.XPATH , using = "//div[@class=\"pull-right\"]//a")
WebElement add_coupon_btn;

@FindBy(how = How.XPATH , using = "//div[@class=\"col-sm-offset-2 col-sm-10\"]//button")
WebElement add_button;

@FindBy(how = How.XPATH , using = "//input[@id=\"coupon_name\"]")
WebElement coupon_textbox;

@FindBy(how = How.XPATH , using = "(//li[@class=\"header-icon dib\"]//span)[1]")
WebElement mainhun_btn;

@FindBy(how = How.XPATH , using = "//a[@href=\"https://xlogist.pisystindia.com/mainhub/login/logout\"]//span")
WebElement logout_btn;

@FindBy(how = How.XPATH , using = "//span[@id=\"coupon_err_msg\"]")
WebElement error_msg;



public void click_login(String username , String password) {
	try {
		Thread.sleep(2000);
		Login_username.sendKeys(username);
		ExtentReportManager.extTest.log(LogStatus.INFO, "Entering Username" + username, "Entered username" + username);
		Thread.sleep(2000);
		Login_password.sendKeys(password);
		ExtentReportManager.extTest.log(LogStatus.INFO, "Entering password" + password, "Entered password" + password);
		Thread.sleep(2000);
		Login_button.click();
		ExtentReportManager.extTest.log(LogStatus.INFO, "Clicking on Login button", "Clicked on Login button");
		Thread.sleep(2000);
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	
}

public void click_logout() {
	try {
		Thread.sleep(2000);
		mainhun_btn.click();
		ExtentReportManager.extTest.log(LogStatus.INFO, "Clicking on Mainhub button", "Clicked on Mainhub button");
		Thread.sleep(2000);
		logout_btn.click();
		ExtentReportManager.extTest.log(LogStatus.INFO, "Clicking on Logout button", "Clicked on Logout button ");
		Thread.sleep(2000);

	}catch(Exception e) {
		e.printStackTrace();
	}
}

public void click_coupon_module() {
	try {
		Thread.sleep(2000);
		coupon_module_btn.click();
		ExtentReportManager.extTest.log(LogStatus.INFO, "Clicking on Coupon Module", "Clicked on Coupon Module");
	}catch(Exception e) {
		e.printStackTrace();
	}
}

public void click_add_coupon() {
	try {
		Thread.sleep(2000);
		add_coupon_btn.click();
		ExtentReportManager.extTest.log(LogStatus.INFO, "Clicking on Add coupon", "Clicked on Add coupon");
	}catch(Exception e) {
		e.printStackTrace();
	}
}

public void click_add() {
	try {
		Thread.sleep(2000);
		add_button.click();
		ExtentReportManager.extTest.log(LogStatus.INFO, "Clicking on Add button", "Clicked on Add button");
	}catch(Exception e) {
		e.printStackTrace();
	}
}

public void enter_coupon_code(String coupon_txt) {
	try {
		Thread.sleep(2000);
		coupon_textbox.sendKeys(coupon_txt);
		ExtentReportManager.extTest.log(LogStatus.INFO, "Entering coupon text" + coupon_txt, "Entered coupon text" + coupon_txt);
	}catch(Exception e) {
		e.printStackTrace();
	}
}


public void add_coupon_valid(String username , String password , String coupon_txt , String expected) {
	try {
		click_login(username, password);
		click_coupon_module();
		click_add_coupon();
		enter_coupon_code(coupon_txt);
		click_add();
		Thread.sleep(3000);
		String actual = add_coupon_btn.getText();
		if(expected.equals(actual)) {
			ExtentReportManager.extTest.log(LogStatus.PASS, "Expected: "+ expected , "Actual" + actual);
		}
		else {
			ExtentReportManager.extTest.log(LogStatus.FAIL, "Expected: "+ expected , "Actual" + actual);

		}
		click_logout();
	}catch(Exception e) {
		e.printStackTrace();
	}
}
	
	public void add_coupon_invalid_special_char(String username , String password , String coupon_txt , String expected) {
		try {
			click_login(username, password);
			click_coupon_module();
			click_add_coupon();
			enter_coupon_code(coupon_txt);
			click_add();
			Thread.sleep(2000);
			String actual = error_msg.getText();
			Thread.sleep(2000);
			if(expected.equals(actual)) {
				ExtentReportManager.extTest.log(LogStatus.PASS, "Expected: "+ expected , "Actual" + actual);
			}
			else {
				ExtentReportManager.extTest.log(LogStatus.FAIL, "Expected: "+ expected , "Actual" + actual);

			}
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
}
	
	public void add_coupon_invalid_alpha_spaces(String username , String password , String coupon_txt , String expected) {
		try {
			click_login(username, password);
			click_coupon_module();
			click_add_coupon();
			enter_coupon_code(coupon_txt);
			click_add();
			Thread.sleep(2000);
			String actual = error_msg.getText();
			Thread.sleep(2000);
			if(expected.equals(actual)) {
				ExtentReportManager.extTest.log(LogStatus.PASS, "Expected: "+ expected , "Actual" + actual);
			}
			else {
				ExtentReportManager.extTest.log(LogStatus.FAIL, "Expected: "+ expected , "Actual" + actual);

			}
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
}
	
	public void add_coupon_invalid_alpha_num(String username , String password , String coupon_txt , String expected) {
		try {
			click_login(username, password);
			click_coupon_module();
			click_add_coupon();
			enter_coupon_code(coupon_txt);
			click_add();
			Thread.sleep(3000);
			String actual = error_msg.getText();
			if(expected.equals(actual)) {
				ExtentReportManager.extTest.log(LogStatus.PASS, "Expected: "+ expected , "Actual" + actual);
			}
			else {
				ExtentReportManager.extTest.log(LogStatus.FAIL, "Expected: "+ expected , "Actual" + actual);

			}
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
}
	
	public void add_coupon_invalid_min_length(String username , String password , String coupon_txt , String expected) {
		try {
			click_login(username, password);
			click_coupon_module();
			click_add_coupon();
			enter_coupon_code(coupon_txt);
			click_add();
			Thread.sleep(3000);
			String actual = error_msg.getText();
			if(expected.equals(actual)) {
				ExtentReportManager.extTest.log(LogStatus.PASS, "Expected: "+ expected , "Actual" + actual);
			}
			else {
				ExtentReportManager.extTest.log(LogStatus.FAIL, "Expected: "+ expected , "Actual" + actual);

			}
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
}
public void add_coupon_invalid_max_length(String username , String password , String coupon_txt , String expected) {
		try {
			click_login(username, password);
			click_coupon_module();
			click_add_coupon();
			enter_coupon_code(coupon_txt);
			click_add();
			Thread.sleep(3000);
			String actual = error_msg.getText();
			if(expected.equals(actual)) {
				ExtentReportManager.extTest.log(LogStatus.PASS, "Expected: "+ expected , "Actual" + actual);
			}
			else {
				ExtentReportManager.extTest.log(LogStatus.FAIL, "Expected: "+ expected , "Actual" + actual);

			}
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
}
	
	public void add_coupon_invalid_empty(String username , String password , String coupon_txt , String expected) {
		try {
			click_login(username, password);
			click_coupon_module();
			click_add_coupon();
			enter_coupon_code(coupon_txt);
			click_add();
			Thread.sleep(3000);
			String actual = error_msg.getText();
			if(expected.equals(actual)) {
				ExtentReportManager.extTest.log(LogStatus.PASS, "Expected: "+ expected , "Actual" + actual);
			}
			else {
				ExtentReportManager.extTest.log(LogStatus.FAIL, "Expected: "+ expected , "Actual" + actual);

			}
			click_logout();
		}catch(Exception e) {
			e.printStackTrace();
		}
}
	
	
	
	
	
	
	
	
	
	
	
	
	

}






























